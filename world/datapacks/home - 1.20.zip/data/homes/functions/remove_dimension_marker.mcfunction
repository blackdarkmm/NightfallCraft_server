forceload remove ~ ~
kill @s